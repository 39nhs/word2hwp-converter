# SPDX-License-Identifier: Apache-2.0
"""``FormField`` — a live view over one 누름틀(click-here) form field control.

Replaces the 20-key dict ``add_form_field``/``fill_form_field``/
``list_form_fields`` returned in 5.x (design §2.3/§2.4 #2). The three id
aliases (``field_id``/``id``/``fieldid``) collapse to :attr:`FormField.field_id`,
the two prompt aliases (``prompt``/``instruction``) collapse to
:attr:`FormField.prompt`, the two type aliases (``field_type``/``control_type``)
collapse to :attr:`FormField.field_type`, and the five index keys
(``section_index``/``paragraph_index``/``paragraph_index_in_section``/
``run_index``/``child_index``) collapse to :class:`FieldLocation`.

The read-only snapshots of the other fields Hancom saves, located the same
way, live here too: :class:`FormulaField` (table formulas) and
:class:`Bookmark`.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Literal

if TYPE_CHECKING:
    import xml.etree.ElementTree as ET

    from ..document import HwpxDocument


@dataclass(frozen=True)
class FieldLocation:
    """Where a :class:`FormField` sits in the document — 5 index keys, one type."""

    section_index: int
    paragraph_index: int
    paragraph_index_in_section: int
    run_index: int
    child_index: int

    def to_dict(self) -> dict[str, Any]:
        return {
            "sectionIndex": self.section_index,
            "paragraphIndex": self.paragraph_index,
            "paragraphIndexInSection": self.paragraph_index_in_section,
            "runIndex": self.run_index,
            "childIndex": self.child_index,
        }


@dataclass(frozen=True)
class FieldParameter:
    """One ``<hp:...Param>`` entry carried on a field's ``<hp:fieldBegin>``."""

    name: str
    value: str

    def to_dict(self) -> dict[str, Any]:
        return {"name": self.name, "value": self.value}


class FormField:
    """A live view over one 누름틀(click-here) ``<hp:fieldBegin>`` control.

    ``value`` is settable: assigning it fills the field through the same
    style-preserving, placeholder-aware path as ``doc.fields.fill`` (it is a
    thin wrapper around :func:`hwpx._document.fields.fill_form_field`), not a
    raw text overwrite. Every other attribute is a snapshot taken when this
    object was built — the same snapshot semantics 5.x's dict already had, so
    nothing gets *less* fresh than before; re-read via ``doc.fields.all`` /
    ``doc.fields.fill`` for the current state.
    """

    __slots__ = (
        "_doc",
        "_element",
        "_field_id",
        "_name",
        "_prompt",
        "_memo",
        "_editable",
        "_value",
        "_field_type",
        "_is_placeholder",
        "_location",
        "_parameters",
        "_has_end",
    )

    def __init__(
        self,
        doc: "HwpxDocument",
        element: "ET.Element",
        *,
        field_id: str,
        name: str,
        prompt: str,
        memo: str,
        editable: bool,
        value: str,
        field_type: str,
        is_placeholder: bool,
        location: FieldLocation,
        parameters: tuple[FieldParameter, ...],
        has_end: bool,
    ) -> None:
        self._doc = doc
        self._element = element
        self._field_id = field_id
        self._name = name
        self._prompt = prompt
        self._memo = memo
        self._editable = editable
        self._value = value
        self._field_type = field_type
        self._is_placeholder = is_placeholder
        self._location = location
        self._parameters = parameters
        self._has_end = has_end

    @property
    def element(self) -> "ET.Element":
        """The wrapped ``<hp:fieldBegin>`` element — the escape hatch."""

        return self._element

    @property
    def field_id(self) -> str:
        return self._field_id

    @property
    def name(self) -> str:
        return self._name

    @property
    def prompt(self) -> str:
        """안내문 shown while the field is empty (absorbs the old ``instruction`` alias)."""

        return self._prompt

    @property
    def memo(self) -> str:
        return self._memo

    @property
    def editable(self) -> bool:
        return self._editable

    @property
    def value(self) -> str:
        """The field's current text content (replaces the old ``current_value`` key).

        A field whose content runs over paragraphs reads as their texts, one
        paragraph per line."""

        return self._value

    @value.setter
    def value(self, new_value: str) -> None:
        # Deferred import: hwpx._document.fields builds FormField instances at
        # module scope, so importing it back at module scope here would cycle.
        # By the time this setter actually runs both modules are fully loaded.
        from .._document.fields import fill_form_field

        result = fill_form_field(self._doc, str(new_value), field_id=self._field_id)
        self._value = result.after
        self._is_placeholder = result.field.is_placeholder

    @property
    def field_type(self) -> str:
        """The field's OWPML type (absorbs the old ``control_type`` alias)."""

        return self._field_type

    @property
    def is_placeholder(self) -> bool:
        return self._is_placeholder

    @property
    def location(self) -> FieldLocation:
        return self._location

    @property
    def parameters(self) -> tuple[FieldParameter, ...]:
        return self._parameters

    @property
    def has_end(self) -> bool:
        """Whether a matching ``<hp:fieldEnd>`` was found for this field, in its
        paragraph or in a later paragraph beside it."""

        return self._has_end

    def __repr__(self) -> str:  # pragma: no cover - debugging aid
        return (
            f"FormField(field_id={self._field_id!r}, name={self._name!r}, "
            f"value={self._value!r}, is_placeholder={self._is_placeholder!r})"
        )




class CellField:
    """A live view over one named table cell -- Hancom's cell field (``hp:tc@name``).

    ``text`` reads the cell's text and, when assigned, replaces the text of the
    cell's own paragraphs (the cell's character and paragraph shapes are kept);
    a table or object inside the cell keeps its text.
    ``cell`` is the table cell itself (:class:`hwpx.model.TableCell`) for anything else.
    """

    __slots__ = ("_cell",)

    def __init__(self, cell: Any) -> None:
        self._cell = cell

    @property
    def name(self) -> str:
        return str(self._cell.field_name)

    @property
    def text(self) -> str:
        return str(self._cell.text)

    @text.setter
    def text(self, value: str) -> None:
        self._cell.set_text(value)

    @property
    def cell(self) -> Any:
        return self._cell

    def to_dict(self) -> dict[str, Any]:
        row, col = self._cell.address
        return {"name": self.name, "text": self.text, "row": row, "column": col}

    def __repr__(self) -> str:  # pragma: no cover - debugging aid
        return f"CellField(name={self.name!r}, text={self.text!r})"


class TextBoxField:
    """A live view over one named text box -- a field for Hancom (``hp:drawText@name``).

    Hancom lists a text box that has a name among its fields and fills it by that
    name. ``text`` reads the box's paragraphs, a line each, and, when assigned,
    replaces them with one paragraph holding the value, as Hancom fills the box:
    the box's first paragraph and its first run keep their shapes.
    ``element`` is the ``hp:drawText`` itself.
    """

    __slots__ = ("_draw_text", "_section")

    def __init__(self, draw_text: Any, section: Any) -> None:
        self._draw_text = draw_text
        self._section = section

    @property
    def name(self) -> str:
        return str(self._draw_text.get("name") or "")

    @property
    def text(self) -> str:
        from .._document.fields import text_box_text

        return text_box_text(self._draw_text)

    @text.setter
    def text(self, value: str) -> None:
        from .._document.fields import set_text_box_text

        set_text_box_text(self._draw_text, self._section, value)

    @property
    def element(self) -> Any:
        return self._draw_text

    def to_dict(self) -> dict[str, Any]:
        return {"name": self.name, "text": self.text}

    def __repr__(self) -> str:  # pragma: no cover - debugging aid
        return f"TextBoxField(name={self.name!r}, text={self.text!r})"


@dataclass(frozen=True)
class FormulaField:
    """One table formula Hancom saved (``<hp:fieldBegin type="FORMULA">``), read as written.

    The values are Hancom's own parameters, not recomputed: ``formula`` keeps
    Hancom's notation as written (``=SUM(A1:A3)``, ``=SUM(?1:?3)``),
    ``last_result`` is the value Hancom last
    computed and ``value`` is the text the document shows. ``cell_address`` is
    the ``(row, column)`` of the table cell holding the formula, ``None`` when it
    sits in an ordinary paragraph. ``element`` is the ``<hp:fieldBegin>``.
    """

    field_id: str
    formula: str
    result_format: str
    last_result: str
    command: str
    value: str
    location: FieldLocation
    cell_address: tuple[int, int] | None
    parameters: tuple[FieldParameter, ...]
    element: Any = field(repr=False, compare=False)

    def to_dict(self) -> dict[str, Any]:
        return {
            "fieldId": self.field_id,
            "formula": self.formula,
            "resultFormat": self.result_format,
            "lastResult": self.last_result,
            "command": self.command,
            "value": self.value,
            "location": self.location.to_dict(),
            "cellAddress": list(self.cell_address) if self.cell_address is not None else None,
            "parameters": [parameter.to_dict() for parameter in self.parameters],
        }


@dataclass(frozen=True)
class Bookmark:
    """A bookmark and where it starts.

    Hancom saves a bookmark in one of two forms, and ``kind`` names the form:
    ``"point"`` is ``<hp:ctrl><hp:bookmark name=".."/></hp:ctrl>`` and ``"field"``
    is a ``<hp:fieldBegin type="BOOKMARK" name="..">`` paired with its
    ``<hp:fieldEnd>``. ``text`` is the text between that begin and end, one line
    per paragraph when they are paragraphs apart; Hancom often writes the pair
    with nothing between, and a point bookmark has no text. ``element`` is the
    ``<hp:bookmark>`` or ``<hp:fieldBegin>``.
    """

    name: str
    kind: Literal["point", "field"]
    text: str
    location: FieldLocation
    element: Any = field(repr=False, compare=False)

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "kind": self.kind,
            "text": self.text,
            "location": self.location.to_dict(),
        }



__all__ = ["Bookmark", "CellField", "FieldLocation", "FieldParameter", "FormField", "FormulaField", "TextBoxField"]
