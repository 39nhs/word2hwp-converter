# SPDX-License-Identifier: Apache-2.0
"""Contents/header.xml style, numbering, tracked-change, and resource service."""

from __future__ import annotations

from copy import deepcopy
from typing import TYPE_CHECKING, Callable, Iterable, Mapping, Sequence
import xml.etree.ElementTree as ET

from lxml import etree as LET  # type: ignore[reportAttributeAccessIssue]  # lxml has no complete bundled typing

from .paragraph_heading import paragraph_heading, set_paragraph_heading
from ._document_primitives import (
    T,
    _FONT_FACE_LANG_TO_REF,
    _HC_NS,
    _HH,
    _HP,
    _allocate_font_id,
    _append_child,
    _append_fill_brush,
    _attach_new_child,
    _apply_optional_attrs,
    _bool_str,
    _border_fill_is_basic_solid_line,
    _border_fill_matches,
    _build_font_element,
    _create_basic_border_fill_element,
    _create_border_fill_element,
    _element_local_name,
    _ensure_memo_shape,
    _ensure_tab_definition_element,
    _find_matching_para_pr,
    _find_font_id,
    _find_shading_border_fill_id,
    _fontface_insert_index,
    _get_bool_attr,
    _get_int_attr,
    _normalize_border_side_names,
    _normalize_border_type,
    _normalize_color,
    _normalize_font_langs,
    _normalize_memo_shape_spec,
    _resolve_font_substitute,
    _serialize_xml,
    _update_item_count,
    _validate_font_type,
)
from .common import GenericElement
from .header import (
    Bullet,
    Header,
    MemoProperties,
    MemoShape,
    ParagraphProperty,
    Style,
    TabDefinition,
    TrackChange,
    TrackChangeAuthor,
    memo_shape_from_attributes,
    parse_bullets,
    parse_border_fills,
    parse_header_element,
    parse_paragraph_properties,
    parse_paragraph_property,
    parse_styles,
    parse_tab_definitions,
    parse_track_change_authors,
    parse_track_change_config,
    parse_track_changes,
    track_change_author_to_xml,
    track_change_to_xml,
)
from .namespaces import tag_local_name, tag_namespace
from .numbering import DocumentNumbering
from .utils import normalize_line_width, parse_int

if TYPE_CHECKING:
    from .document_parts import HwpxOxmlDocument


class HwpxOxmlHeader:
    """Represents a header XML part."""

    def __init__(self, part_name: str, element: ET.Element, document: "HwpxOxmlDocument" | None = None):  # type: ignore[reportGeneralTypeIssues]  # frozen public annotation
        self.part_name = part_name
        self._element = element
        self._dirty = False
        self._document = document
        # parsed lookups (paragraph shapes, styles, tab definitions, border fills ...), see _parsed()
        self._lookup_cache: dict[tuple[object, ET.Element], tuple[bytes, object]] = {}
        self._para_pr_index: tuple[object, dict[str, ET.Element]] | None = None

    @property
    def element(self) -> ET.Element:
        return self._element

    @property
    def document(self) -> "HwpxOxmlDocument" | None:  # type: ignore[reportGeneralTypeIssues]  # frozen public annotation
        return self._document

    def attach_document(self, document: "HwpxOxmlDocument") -> None:
        self._document = document

    def to_model(self) -> Header:
        return parse_header_element(self._convert_to_lxml(self._element))

    @staticmethod
    def _coerce_serialized_child(parent: ET.Element, child: LET._Element) -> ET.Element:
        if isinstance(parent, LET._Element):
            return child
        return ET.fromstring(LET.tostring(child, encoding="utf-8"))

    def _begin_num_element(self, create: bool = False) -> ET.Element | None:
        element = self._element.find(f"{_HH}beginNum")
        if element is None and create:
            element = self._element.makeelement(f"{_HH}beginNum", {})
            self._element.append(element)
        return element

    def _ref_list_element(self, create: bool = False) -> ET.Element | None:
        element = self._element.find(f"{_HH}refList")
        if element is None and create:
            element = self._element.makeelement(f"{_HH}refList", {})
            self._element.append(element)
            self.mark_dirty()
        return element

    def _ref_list_default_child(self, tag: str, *, create: bool = False) -> ET.Element | None:
        """Find-or-create a direct ``refList`` child defaulting to an empty
        ``itemCnt="0"`` collection. Shared body for the sibling accessors
        below — ``fontfaces`` is the one exception needing first-child
        positioning (schema requires it precede the others), so it keeps
        its own method.
        """

        ref_list = self._ref_list_element(create=create)
        if ref_list is None:
            return None
        element = ref_list.find(f"{_HH}{tag}")
        if element is None and create:
            element = ref_list.makeelement(f"{_HH}{tag}", {"itemCnt": "0"})
            ref_list.append(element)
            self.mark_dirty()
        return element

    def _border_fills_element(self, create: bool = False) -> ET.Element | None:
        return self._ref_list_default_child("borderFills", create=create)

    def _char_properties_element(self, create: bool = False) -> ET.Element | None:
        return self._ref_list_default_child("charProperties", create=create)

    def _fontfaces_element(self, create: bool = False) -> ET.Element | None:
        ref_list = self._ref_list_element(create=create)
        if ref_list is None:
            return None
        element = ref_list.find(f"{_HH}fontfaces")
        if element is None and create:
            element = ref_list.makeelement(f"{_HH}fontfaces", {"itemCnt": "0"})
            # 스키마 순서: MappingTableType 시퀀스에서 fontfaces 가 첫 자식이다.
            ref_list.insert(0, element)
            self.mark_dirty()
        return element

    def _allocate_style_id(self, element: ET.Element) -> str:
        existing: set[str] = {child.get("id") or "" for child in element.findall(f"{_HH}style")}
        existing.discard("")

        numeric_ids: list[int] = []
        for value in existing:
            try:
                numeric_ids.append(int(value))
            except ValueError:
                continue
        next_id = 0 if not numeric_ids else max(numeric_ids) + 1
        candidate = str(next_id)
        while candidate in existing:
            next_id += 1
            candidate = str(next_id)
        return candidate

    def font_ref_for_face(self, face: str) -> dict[str, str] | None:
        """Return ``hh:fontRef`` attributes for the languages that declare *face*.

        Each language numbers its fonts on its own, so a language that does
        not declare *face* gets no entry (its reference stays as it was).
        """

        target = face.strip()
        if not target:
            return None

        refs: dict[str, str] = {}
        for fontface in self._element.findall(f".//{_HH}fontface"):
            attr_name = _FONT_FACE_LANG_TO_REF.get(fontface.get("lang", "").upper())
            if attr_name is None:
                continue
            for font in fontface.findall(f"{_HH}font"):
                if font.get("face") == target and font.get("id"):
                    refs[attr_name] = font.get("id", "")
                    break

        return refs or None

    def _allocate_char_property_id(
        self,
        element: ET.Element,
        *,
        preferred_id: str | int | None = None,
    ) -> str:
        existing: set[str] = {
            child.get("id") or ""
            for child in element.findall(f"{_HH}charPr")
        }
        existing.discard("")

        if preferred_id is not None:
            candidate = str(preferred_id)
            if candidate not in existing:
                return candidate

        numeric_ids: list[int] = []
        for value in existing:
            try:
                numeric_ids.append(int(value))
            except ValueError:
                continue
        next_id = 0 if not numeric_ids else max(numeric_ids) + 1
        candidate = str(next_id)
        while candidate in existing:
            next_id += 1
            candidate = str(next_id)
        return candidate

    def _allocate_border_fill_id(self, element: ET.Element) -> str:
        existing: set[str] = {
            child.get("id") or ""
            for child in element.findall(f"{_HH}borderFill")
        }
        existing.discard("")

        numeric_ids: list[int] = []
        for value in existing:
            try:
                numeric_ids.append(int(value))
            except ValueError:
                continue
        next_id = 0 if not numeric_ids else max(numeric_ids) + 1
        candidate = str(next_id)
        while candidate in existing:
            next_id += 1
            candidate = str(next_id)
        return candidate

    def ensure_char_property(
        self,
        *,
        predicate: Callable[[ET.Element], bool] | None = None,
        modifier: Callable[[ET.Element], None] | None = None,
        base_char_pr_id: str | int | None = None,
        preferred_id: str | int | None = None,
    ) -> ET.Element:
        """Return a ``<hh:charPr>`` element matching *predicate* or create one.

        When an existing entry satisfies *predicate*, it is returned unchanged.
        Otherwise a new element is produced by cloning ``base_char_pr_id`` (or the
        first available entry) and applying *modifier* before assigning a fresh
        identifier and updating ``itemCnt``.
        """

        char_props = self._char_properties_element(create=True)
        if char_props is None:  # pragma: no cover - defensive branch
            raise RuntimeError("failed to create <charProperties> element")

        if predicate is not None:
            for child in char_props.findall(f"{_HH}charPr"):
                if predicate(child):
                    return child

        base_element: ET.Element | None = None
        if base_char_pr_id is not None:
            base_element = char_props.find(f"{_HH}charPr[@id='{base_char_pr_id}']")
        if base_element is None:
            existing = char_props.find(f"{_HH}charPr")
            if existing is not None:
                base_element = existing

        if base_element is None:
            new_char_pr = ET.Element(f"{_HH}charPr")
        else:
            new_char_pr = deepcopy(base_element)
            if "id" in new_char_pr.attrib:
                del new_char_pr.attrib["id"]

        if modifier is not None:
            modifier(new_char_pr)

        char_id = self._allocate_char_property_id(char_props, preferred_id=preferred_id)
        new_char_pr.set("id", char_id)
        char_props.append(new_char_pr)
        _update_item_count(char_props, "charPr")
        self.mark_dirty()
        document = self.document
        if document is not None:
            document.invalidate_char_property_cache()
        return new_char_pr

    def _memo_properties_element(self, create: bool = False) -> ET.Element | None:
        return self._ref_list_default_child("memoProperties", create=create)

    def _bullets_element(self, create: bool = False) -> ET.Element | None:
        return self._ref_list_default_child("bullets", create=create)

    def _numberings_element(self, create: bool = False) -> ET.Element | None:
        return self._ref_list_default_child("numberings", create=create)

    def _para_properties_element(self, create: bool = False) -> ET.Element | None:
        return self._ref_list_default_child("paraProperties", create=create)

    def _tab_properties_element(self, create: bool = False) -> ET.Element | None:
        return self._ref_list_default_child("tabProperties", create=create)

    @staticmethod
    def _allocate_ref_id(parent: ET.Element, child_tag: str) -> str:
        existing: set[str] = {
            child.get("id") or ""
            for child in parent.findall(child_tag)
        }
        existing.discard("")
        numeric_ids: list[int] = []
        for value in existing:
            try:
                numeric_ids.append(int(value))
            except ValueError:
                continue
        next_id = 1 if not numeric_ids else max(numeric_ids) + 1
        candidate = str(next_id)
        while candidate in existing:
            next_id += 1
            candidate = str(next_id)
        return candidate

    @staticmethod
    def _update_item_count(parent: ET.Element, child_tag: str) -> None:
        parent.set("itemCnt", str(len(parent.findall(child_tag))))

    @staticmethod
    def _default_para_head_attributes(level: int) -> dict[str, str]:
        return {
            "start": "1",
            "level": str(level),
            "align": "LEFT",
            "useInstWidth": "1",
            "autoIndent": "1",
            "widthAdjust": "0",
            "textOffsetType": "PERCENT",
            "textOffset": "50",
            "numFormat": "DIGIT",
            "charPrIDRef": "4294967295",
            "checkable": "0",
        }

    def _ensure_bullet_definition(self, char: str) -> str:
        bullets = self._bullets_element(create=True)
        if bullets is None:  # pragma: no cover - defensive branch
            raise RuntimeError("failed to create <bullets> element")
        for bullet in bullets.findall(f"{_HH}bullet"):
            if bullet.get("char") == char:
                bullet_id = bullet.get("id")
                if bullet_id:
                    return bullet_id

        bullet_id = self._allocate_ref_id(bullets, f"{_HH}bullet")
        bullet = bullets.makeelement(
            f"{_HH}bullet",
            {"id": bullet_id, "char": char, "useImage": "0"},
        )
        head_attrs = self._default_para_head_attributes(0)
        head_attrs.pop("start", None)
        head_attrs["useInstWidth"] = "0"
        _append_child(bullet, f"{_HH}paraHead", head_attrs)
        bullets.append(bullet)
        self._update_item_count(bullets, f"{_HH}bullet")
        self.mark_dirty()
        return bullet_id

    def _create_numbering_definition(self, levels: int | Sequence[Mapping[str, str]]) -> str:
        if isinstance(levels, int):
            level_specs: list[Mapping[str, str]] = [{} for _ in range(max(1, levels))]
        else:
            level_specs = list(levels) or [{}]

        numberings = self._numberings_element(create=True)
        if numberings is None:  # pragma: no cover - defensive branch
            raise RuntimeError("failed to create <numberings> element")

        first_start = str(level_specs[0].get("start") or "1")
        numbering_id = self._allocate_ref_id(numberings, f"{_HH}numbering")
        numbering = numberings.makeelement(
            f"{_HH}numbering",
            {"id": numbering_id, "start": first_start},
        )
        for index, level_spec in enumerate(level_specs):
            level = index + 1
            head_attrs = self._default_para_head_attributes(level)
            num_format = level_spec.get("numFormat") or level_spec.get("format")
            if num_format:
                head_attrs["numFormat"] = str(num_format).upper()
            start = level_spec.get("start")
            if start is not None:
                head_attrs["start"] = str(start)
            head = _append_child(
                numbering,
                f"{_HH}paraHead",
                head_attrs,
            )
            head.text = str(
                level_spec.get("text")
                or ".".join(f"^{part}" for part in range(1, level + 1)) + "."
            )
        numberings.append(numbering)
        self._update_item_count(numberings, f"{_HH}numbering")
        self.mark_dirty()
        return numbering_id

    def _ensure_para_property_heading(
        self,
        *,
        heading_type: str,
        id_ref: str,
        level: int,
    ) -> str:
        para_properties = self._para_properties_element(create=True)
        if para_properties is None:  # pragma: no cover - defensive branch
            raise RuntimeError("failed to create <paraProperties> element")

        for para_pr in para_properties.findall(f"{_HH}paraPr"):
            heading = paragraph_heading(para_pr)
            if heading is None:
                continue
            if (
                heading.get("type") == heading_type
                and heading.get("idRef") == str(id_ref)
                and heading.get("level") == str(level)
            ):
                para_pr_id = para_pr.get("id")
                if para_pr_id:
                    return para_pr_id

        base = para_properties.find(f"{_HH}paraPr")
        para_pr = deepcopy(base) if base is not None else para_properties.makeelement(f"{_HH}paraPr", {})
        para_pr.attrib.pop("id", None)
        set_paragraph_heading(para_pr, {"type": heading_type, "idRef": str(id_ref), "level": str(level)})
        para_pr_id = self._allocate_ref_id(para_properties, f"{_HH}paraPr")
        para_pr.set("id", para_pr_id)
        para_properties.append(para_pr)
        self._update_item_count(para_properties, f"{_HH}paraPr")
        self.mark_dirty()
        return para_pr_id

    def ensure_paragraph_alignment(self, align: str) -> str:
        """Return a paragraph property id with the requested horizontal alignment."""

        horizontal = self._normalize_paragraph_alignment(align)

        para_properties = self._para_properties_element(create=True)
        if para_properties is None:  # pragma: no cover - defensive branch
            raise RuntimeError("failed to create <paraProperties> element")

        for para_pr in para_properties.findall(f"{_HH}paraPr"):
            align_element = para_pr.find(f"{_HH}align")
            if align_element is not None and align_element.get("horizontal") == horizontal:
                para_pr_id = para_pr.get("id")
                if para_pr_id:
                    return para_pr_id

        base = para_properties.find(f"{_HH}paraPr")
        para_pr = deepcopy(base) if base is not None else para_properties.makeelement(f"{_HH}paraPr", {})
        para_pr.attrib.pop("id", None)
        align_element = para_pr.find(f"{_HH}align")
        if align_element is None:
            align_element = para_pr.makeelement(
                f"{_HH}align",
                {"horizontal": horizontal, "vertical": "BASELINE"},
            )
            para_pr.insert(0, align_element)
        else:
            align_element.set("horizontal", horizontal)
            if align_element.get("vertical") is None:
                align_element.set("vertical", "BASELINE")
        para_pr_id = self._allocate_ref_id(para_properties, f"{_HH}paraPr")
        para_pr.set("id", para_pr_id)
        para_properties.append(para_pr)
        self._update_item_count(para_properties, f"{_HH}paraPr")
        self.mark_dirty()
        return para_pr_id

    @staticmethod
    def _normalize_paragraph_alignment(align: str) -> str:
        normalized = align.strip().upper()
        aliases = {
            "LEFT": "LEFT",
            "START": "LEFT",
            "CENTER": "CENTER",
            "CENTRE": "CENTER",
            "MIDDLE": "CENTER",
            "RIGHT": "RIGHT",
            "END": "RIGHT",
            "JUSTIFY": "JUSTIFY",
            "DISTRIBUTE": "DISTRIBUTE",
            "DISTRIBUTE_SPACE": "DISTRIBUTE_SPACE",
        }
        horizontal = aliases.get(normalized)
        if horizontal is None:
            raise ValueError(f"unsupported paragraph alignment: {align}")
        return horizontal

    @staticmethod
    def _id_matches(raw_id: str | None, target: str | int | None) -> bool:
        if raw_id is None or target is None:
            return False
        raw = str(raw_id).strip()
        candidate = str(target).strip()
        if raw == candidate:
            return True
        try:
            return int(raw) == int(candidate)
        except ValueError:
            return False

    @staticmethod
    def _direct_child_by_local(parent: ET.Element, local_name: str) -> ET.Element | None:
        for child in parent:
            if _element_local_name(child) == local_name:
                return child
        return None

    @staticmethod
    def _descendants_by_local(parent: ET.Element, local_name: str) -> list[ET.Element]:
        return [
            child
            for child in parent.iter()
            if child is not parent and _element_local_name(child) == local_name
        ]

    @staticmethod
    def _remove_descendants_by_local(parent: ET.Element, local_name: str) -> None:
        for candidate_parent in list(parent.iter()):
            for child in list(candidate_parent):
                if _element_local_name(child) == local_name:
                    candidate_parent.remove(child)

    @staticmethod
    def _insert_child_after(
        parent: ET.Element,
        child: ET.Element,
        after_local_names: set[str],
    ) -> None:
        insert_at = 0
        for index, existing in enumerate(list(parent)):
            if _element_local_name(existing) in after_local_names:
                insert_at = index + 1
        parent.insert(insert_at, child)

    def _ensure_direct_para_child(
        self,
        para_pr: ET.Element,
        local_name: str,
        *,
        after_local_names: set[str],
    ) -> ET.Element:
        child = self._direct_child_by_local(para_pr, local_name)
        if child is not None:
            return child
        child = para_pr.makeelement(f"{_HH}{local_name}", {})
        self._insert_child_after(para_pr, child, after_local_names)
        return child

    def _base_para_property(
        self,
        para_properties: ET.Element,
        base_para_pr_id: str | int | None,
    ) -> ET.Element | None:
        if base_para_pr_id is not None:
            for para_pr in para_properties.findall(f"{_HH}paraPr"):
                if self._id_matches(para_pr.get("id"), base_para_pr_id):
                    return para_pr
        return para_properties.find(f"{_HH}paraPr")

    @staticmethod
    def _set_margin_unit_value(element: ET.Element, value: int) -> None:
        safe_value = str(int(value))
        if "value" in element.attrib or tag_namespace(element.tag) == _HC_NS:
            element.set("value", safe_value)
            element.set("unit", "HWPUNIT")
            element.text = None
            return
        element.text = safe_value
        if "unit" in element.attrib:
            element.set("unit", "HWPUNIT")

    def _apply_paragraph_margins(self, para_pr: ET.Element, margins: Mapping[str, int]) -> None:
        margin_elements = self._descendants_by_local(para_pr, "margin")
        if not margin_elements:
            margin_elements = [self._ensure_direct_para_child(
                para_pr, "margin", after_local_names={"breakSetting", "autoSpacing", "heading", "align"})]

        # Hancom keeps hp:default at twice the hp:case value; a margin outside hp:switch is as given.
        doubled = para_pr.findall(f"{_HP}switch/{_HP}default/{_HH}margin")
        for margin in margin_elements:
            scale = 2 if margin in doubled else 1
            for name, value in margins.items():
                if value is None:
                    continue
                child = self._direct_child_by_local(margin, name)
                if child is None:
                    child = margin.makeelement(f"{_HH}{name}", {})
                    margin.append(child)
                self._set_margin_unit_value(child, int(value) * scale)

    def _apply_paragraph_line_spacing(self, para_pr: ET.Element, percent: int | float) -> None:
        value = str(int(round(float(percent))))
        line_spacing_elements = self._descendants_by_local(para_pr, "lineSpacing")
        if not line_spacing_elements:
            line_spacing = self._ensure_direct_para_child(
                para_pr,
                "lineSpacing",
                after_local_names={"margin"},
            )
            line_spacing_elements = [line_spacing]
        for line_spacing in line_spacing_elements:
            line_spacing.set("type", "PERCENT")
            line_spacing.set("value", value)
            line_spacing.set("unit", "HWPUNIT")  # as Hancom writes a percentage too (the schema's CHAR|HWPUNIT)

    def _apply_paragraph_border(self, para_pr: ET.Element, border: Mapping[str, str | int]) -> None:
        self._remove_descendants_by_local(para_pr, "border")
        attrs = {
            "borderFillIDRef": str(border.get("borderFillIDRef", border.get("border_fill_id_ref", "0"))),
            "offsetLeft": str(border.get("offsetLeft", border.get("offset_left", "0"))),
            "offsetRight": str(border.get("offsetRight", border.get("offset_right", "0"))),
            "offsetTop": str(border.get("offsetTop", border.get("offset_top", "0"))),
            "offsetBottom": str(border.get("offsetBottom", border.get("offset_bottom", "0"))),
            "connect": str(border.get("connect", "0")),
            "ignoreMargin": str(border.get("ignoreMargin", border.get("ignore_margin", "0"))),
        }
        border_element = para_pr.makeelement(f"{_HH}border", attrs)
        self._insert_child_after(
            para_pr,
            border_element,
            {"align", "heading", "breakSetting", "autoSpacing", "margin", "lineSpacing", "switch"},
        )

    def _apply_paragraph_break_setting(
        self, para_pr: ET.Element, break_setting: Mapping[str, bool]
    ) -> None:
        element = self._ensure_direct_para_child(
            para_pr,
            "breakSetting",
            after_local_names={"align", "heading"},
        )
        attr_map = {
            "keep_with_next": "keepWithNext",
            "keep_lines": "keepLines",
            "page_break_before": "pageBreakBefore",
            "widow_orphan": "widowOrphan",
        }
        for key, attr in attr_map.items():
            if key in break_setting and break_setting[key] is not None:
                element.set(attr, "1" if break_setting[key] else "0")

    def ensure_paragraph_format(
        self,
        *,
        base_para_pr_id: str | int | None = None,
        alignment: str | None = None,
        line_spacing_percent: int | float | None = None,
        margins: Mapping[str, int] | None = None,
        heading: Mapping[str, str | int] | None = None,
        border: Mapping[str, str | int] | None = None,
        break_setting: Mapping[str, bool] | None = None,
        tab_pr_id_ref: str | None = None,
    ) -> str:
        """Return a new paragraph property id with requested formatting changes."""

        para_properties = self._para_properties_element(create=True)
        if para_properties is None:  # pragma: no cover - defensive branch
            raise RuntimeError("failed to create <paraProperties> element")

        base = self._base_para_property(para_properties, base_para_pr_id)
        para_pr = deepcopy(base) if base is not None else para_properties.makeelement(f"{_HH}paraPr", {})
        para_pr.attrib.pop("id", None)

        if alignment is not None:
            align_element = self._ensure_direct_para_child(
                para_pr,
                "align",
                after_local_names=set(),
            )
            align_element.set("horizontal", self._normalize_paragraph_alignment(alignment))
            if align_element.get("vertical") is None:
                align_element.set("vertical", "BASELINE")

        if heading is not None:
            set_paragraph_heading(para_pr, {
                "type": str(heading.get("type", "NONE")).upper(),
                "idRef": str(heading.get("idRef", heading.get("id_ref", "0"))),
                "level": str(heading.get("level", "0")),
            })

        clean_margins = {name: value for name, value in dict(margins or {}).items() if value is not None}
        if clean_margins:
            self._apply_paragraph_margins(para_pr, clean_margins)

        if line_spacing_percent is not None:
            self._apply_paragraph_line_spacing(para_pr, line_spacing_percent)

        if break_setting is not None:
            self._apply_paragraph_break_setting(para_pr, break_setting)
        if border is not None:
            self._apply_paragraph_border(para_pr, border)
        if tab_pr_id_ref is not None:
            para_pr.set("tabPrIDRef", str(tab_pr_id_ref))

        # Dedupe (ensure_tab_definition/ensure_style precedent): if the
        # paraPr we just built is structurally identical to one that
        # already exists, reuse its id instead of minting a duplicate.
        # Without this, every add_heading()/set_paragraph_format() call
        # mints a fresh paraPr even when an earlier call already produced
        # the exact same one -- real Hancom merges these duplicates back
        # down on its own next save (observed: a paraPrIDRef that
        # round-tripped through real Hancom came back renumbered, not a
        # bug -- see docs/owpml-deviations.md and the titleMark re-probe
        # notes), so this closes the gap rather than fixing a rejection.
        reusable_id = _find_matching_para_pr(para_properties, para_pr)
        if reusable_id is not None:
            return reusable_id

        para_pr_id = self._allocate_ref_id(para_properties, f"{_HH}paraPr")
        para_pr.set("id", para_pr_id)
        para_properties.append(para_pr)
        self._update_item_count(para_properties, f"{_HH}paraPr")
        self.mark_dirty()
        return para_pr_id

    def ensure_tab_definition(
        self,
        *,
        tab_stops: "Iterable[Mapping[str, object]] | None" = None,
        auto_tab_left: bool = False,
        auto_tab_right: bool = False,
    ) -> str:
        """Return a ``hh:tabPr`` id matching *tab_stops* (dedupe — ``ensure_style``
        선례). Order is part of the dedupe key — see :func:`_normalize_tab_stops`.
        """

        element = self._tab_properties_element(create=True)
        if element is None:  # pragma: no cover - defensive branch
            from ..errors import HwpxStateError

            raise HwpxStateError(
                "failed to create <tabProperties> element",
                code="style-tab-container-create-failed",
            )

        tab_id, created = _ensure_tab_definition_element(
            element,
            tab_stops=tab_stops,
            auto_tab_left=auto_tab_left,
            auto_tab_right=auto_tab_right,
        )
        if created:
            self.mark_dirty()
        return tab_id

    def ensure_numbering(
        self,
        *,
        kind: str,
        levels: Sequence[dict[str, str]] | None = None,
    ) -> list[str]:
        """글머리표/번호/개요 정의를 보장하고 각 레벨의 paraPr id를 돌려준다.

        구현 본체는 `numbering_kinds.py`에 산다(owner-file 1600줄 캡에
        헤드룸이 없어, 6.13 트레인㊻가 `outline` kind를 추가하며 이동).
        """
        from .numbering_kinds import ensure_numbering_refs

        return ensure_numbering_refs(self, kind=kind, levels=levels)

    def _styles_element(self, create: bool = False) -> ET.Element | None:
        ref_list = self._ref_list_element(create=create)
        if ref_list is None:
            return None
        element = ref_list.find(f"{_HH}styles")
        if element is None and create:
            element = ref_list.makeelement(f"{_HH}styles", {"itemCnt": "0"})
            ref_list.append(element)
            self.mark_dirty()
        return element

    def _track_changes_element(self, create: bool = False) -> ET.Element | None:
        ref_list = self._ref_list_element(create=create)
        if ref_list is None:
            return None
        return ref_list.find(f"{_HH}trackChanges")

    def _track_changes_element_or_create(self) -> ET.Element:
        ref_list = self._ref_list_element(create=True)
        if ref_list is None:  # pragma: no cover - defensive branch
            raise RuntimeError("failed to create <refList> element")
        element = ref_list.find(f"{_HH}trackChanges")
        if element is None:
            element = ref_list.makeelement(f"{_HH}trackChanges", {"itemCnt": "0"})
            ref_list.append(element)
            self.mark_dirty()
        return element

    def _track_change_authors_element(self, create: bool = False) -> ET.Element | None:
        ref_list = self._ref_list_element(create=create)
        if ref_list is None:
            return None
        return ref_list.find(f"{_HH}trackChangeAuthors")

    def _track_change_authors_element_or_create(self) -> ET.Element:
        ref_list = self._ref_list_element(create=True)
        if ref_list is None:  # pragma: no cover - defensive branch
            raise RuntimeError("failed to create <refList> element")
        element = ref_list.find(f"{_HH}trackChangeAuthors")
        if element is None:
            element = ref_list.makeelement(f"{_HH}trackChangeAuthors", {"itemCnt": "0"})
            ref_list.append(element)
            self.mark_dirty()
        return element

    def _track_change_config_element(self, create: bool = False) -> ET.Element | None:
        for child in self._element:
            if tag_local_name(child.tag) in {"trackchageConfig", "trackchangeConfig"}:
                return child
        if not create:
            return None
        element = self._element.makeelement(f"{_HH}trackchageConfig", {"flags": "0"})
        self._element.append(element)
        self.mark_dirty()
        return element

    @property
    def track_change_config(self):
        element = self._track_change_config_element()
        if element is None:
            return None
        return parse_track_change_config(self._convert_to_lxml(element))

    def add_track_change(
        self,
        change_type: str,
        *,
        author_name: str = "AI Agent",
        date: str | None = None,
    ) -> int:
        model = self.to_model()
        change_id = model.add_track_change(
            change_type,
            author_name=author_name,
            date=date,
        )
        if model.ref_list is None or model.ref_list.track_changes is None:
            raise RuntimeError("failed to create tracked-change metadata")

        change = next(
            candidate
            for candidate in model.ref_list.track_changes.changes
            if candidate.id == change_id
        )
        changes_element = self._track_changes_element_or_create()
        changes_element.append(
            self._coerce_serialized_child(changes_element, track_change_to_xml(change))
        )
        changes_element.set("itemCnt", str(model.ref_list.track_changes.item_cnt or 0))

        authors = model.ref_list.track_change_authors
        if authors is not None and change.author_id is not None:
            author = authors.author_by_id(change.author_id)
            if author is not None:
                authors_element = self._track_change_authors_element_or_create()
                existing_ids = {
                    child.get("id")
                    for child in authors_element.findall(f"{_HH}trackChangeAuthor")
                }
                author_ids = {str(author.id)} if author.id is not None else set()
                if author.raw_id is not None:
                    author_ids.add(author.raw_id)
                if not existing_ids.intersection(author_ids):
                    authors_element.append(
                        self._coerce_serialized_child(
                            authors_element,
                            track_change_author_to_xml(author),
                        )
                    )
                authors_element.set("itemCnt", str(authors.item_cnt or 0))

        config_element = self._track_change_config_element(create=True)
        if config_element is None:  # pragma: no cover - defensive branch
            raise RuntimeError("failed to create <trackchageConfig> element")
        flags = 1
        if model.track_change_config is not None and model.track_change_config.flags is not None:
            flags = model.track_change_config.flags
        config_element.set("flags", str(flags | 1))
        self.mark_dirty()
        return change_id

    def find_basic_border_fill_id(self) -> str | None:
        element = self._border_fills_element()
        if element is None:
            return None
        for child in element.findall(f"{_HH}borderFill"):
            if _border_fill_is_basic_solid_line(child):
                identifier = child.get("id")
                if identifier:
                    return identifier
        return None

    def ensure_basic_border_fill(self) -> str:
        element = self._border_fills_element(create=True)
        if element is None:  # pragma: no cover - defensive branch
            raise RuntimeError("failed to create <borderFills> element")

        existing = self.find_basic_border_fill_id()
        if existing is not None:
            return existing

        new_id = self._allocate_border_fill_id(element)
        new_border_fill = _create_basic_border_fill_element(new_id)
        _attach_new_child(element, new_border_fill)
        _update_item_count(element, "borderFill")
        self.mark_dirty()
        return new_id

    #: The border types Hancom reads; it draws a type it does not know as no border at all.
    _BORDER_LINE_TYPES = frozenset({
        "SOLID", "DASH", "DOT", "DASH_DOT", "DASH_DOT_DOT", "LONG_DASH",
        "CIRCLE", "DOUBLE_SLIM", "SLIM_THICK", "THICK_SLIM", "SLIM_THICK_SLIM",
        "WAVE", "DOUBLEWAVE", "THICK3D", "THICKREV3D", "3D", "REV3D",
    })
    #: Earlier python-hwpx names of the 3-D lines, which Hancom reads as no line.
    _BORDER_LINE_TYPE_ALIASES = {"THICK_3D": "THICK3D", "THICK_3D_REVERSE_LIGHTING": "THICKREV3D",
                                 "SLIM_3D": "3D", "SLIM_3D_REVERSE_LIGHTING": "REV3D"}

    def ensure_border_fill(
        self,
        *,
        border_color: str = "#BFBFBF",
        border_width: str = "0.12 mm",
        fill_color: str | None = None,
        fill_image: Mapping[str, str] | None = None,
        fill_gradient: Mapping[str, object] | None = None,
        active_borders: Iterable[str] | None = None,
        border_type: str = "SOLID",
    ) -> str:
        element = self._border_fills_element(create=True)
        if element is None:  # pragma: no cover - defensive branch
            raise RuntimeError("failed to create <borderFills> element")

        normalized_border_type = _normalize_border_type(
            self._BORDER_LINE_TYPE_ALIASES.get(str(border_type).upper(), border_type), self._BORDER_LINE_TYPES)
        normalized_border_color = _normalize_color(border_color) or "#BFBFBF"
        normalized_border_width = normalize_line_width(border_width or "0.12 mm")
        normalized_active_borders = _normalize_border_side_names(active_borders)
        normalized_fill_color = _normalize_color(fill_color)

        for border_fill in element.findall(f"{_HH}borderFill"):
            if _border_fill_matches(
                border_fill,
                border_color=normalized_border_color,
                border_width=normalized_border_width,
                fill_color=normalized_fill_color,
                fill_image=fill_image, fill_gradient=fill_gradient,
                active_borders=normalized_active_borders,
                border_type=normalized_border_type,
            ):
                border_id = border_fill.get("id")
                if border_id:
                    return border_id

        new_id = self._allocate_border_fill_id(element)
        new_border_fill = _create_border_fill_element(
            new_id,
            border_color=normalized_border_color,
            border_width=normalized_border_width,
            fill_color=normalized_fill_color,
            fill_image=fill_image, fill_gradient=fill_gradient,
            active_borders=normalized_active_borders,
            border_type=normalized_border_type,
        )
        _attach_new_child(element, new_border_fill)
        _update_item_count(element, "borderFill")
        self.mark_dirty()
        return new_id

    def ensure_style(
        self,
        name: str,
        *,
        style_type: str | None = None,
        eng_name: str | None = None,
        para_pr_id_ref: str | int | None = None,
        char_pr_id_ref: str | int | None = None,
        next_style_id_ref: str | int | None = None,
        lang_id: int | None = None,
        lock_form: bool | None = None,
    ) -> str:
        """Return a style id for *name*, creating or partially updating a ``<hh:style>``.

        *name* is the dedupe key(Hancom style identity is name-based) — a
        repeat call with a *name* that already exists reuses that style's id
        instead of creating a duplicate(``hh:name`` must stay unique for
        :meth:`HwpxOxmlDocument._style_name_id_map` to resolve it
        unambiguously). Any other keyword left as ``None`` leaves that
        attribute untouched on an existing style; on a brand-new style,
        ``style_type`` defaults to ``"PARA"`` (the schema has no default —
        every style must declare a type) and the rest stay unset like real
        Hancom output.
        """

        styles = self._styles_element(create=True)
        if styles is None:  # pragma: no cover - defensive branch
            # The four sibling ensure_* guards above predate the typed-error
            # vocabulary and are grandfathered in the census; new raises are
            # not — the ratchet caught this one on merge, as designed.
            from ..errors import HwpxStateError

            raise HwpxStateError(
                "failed to create <styles> element",
                code="style-container-create-failed",
            )

        normalized_name = str(name)
        element: ET.Element | None = None
        for candidate in styles.findall(f"{_HH}style"):
            if candidate.get("name") == normalized_name:
                element = candidate
                break

        changed = False
        if element is None:
            new_id = self._allocate_style_id(styles)
            new_style = ET.Element(
                f"{_HH}style",
                {"id": new_id, "type": style_type or "PARA", "name": normalized_name},
            )
            if isinstance(styles, LET._Element):
                new_style = LET.fromstring(ET.tostring(new_style, encoding="utf-8"))
            styles.append(new_style)
            element = new_style
            changed = True
        elif style_type is not None and element.get("type") != style_type:
            element.set("type", style_type)
            changed = True

        if _apply_optional_attrs(
            element,
            (
                ("engName", eng_name),
                ("paraPrIDRef", None if para_pr_id_ref is None else str(para_pr_id_ref)),
                ("charPrIDRef", None if char_pr_id_ref is None else str(char_pr_id_ref)),
                ("nextStyleIDRef", None if next_style_id_ref is None else str(next_style_id_ref)),
                ("langID", None if lang_id is None else str(lang_id)),
            ),
        ):
            changed = True
        if lock_form is not None and _get_bool_attr(element, "lockForm", False) != lock_form:
            element.set("lockForm", _bool_str(lock_form))
            changed = True

        if changed:
            _update_item_count(styles, "style")
            self.mark_dirty()
        style_id = element.get("id")
        assert style_id is not None  # allocated above or already present
        return style_id

    def _fontface_element(
        self, fontfaces: ET.Element, lang: str, *, create: bool = False
    ) -> ET.Element | None:
        for child in fontfaces.findall(f"{_HH}fontface"):
            if child.get("lang") == lang:
                return child
        if not create:
            return None

        element = fontfaces.makeelement(f"{_HH}fontface", {"lang": lang, "fontCnt": "0"})
        fontfaces.insert(_fontface_insert_index(fontfaces, lang), element)
        fontfaces.set("itemCnt", str(len(fontfaces.findall(f"{_HH}fontface"))))
        self.mark_dirty()
        return element

    def ensure_font(
        self,
        face: str,
        *,
        lang: "str | Iterable[str] | None" = None,
        font_type: str = "TTF",
        is_embedded: bool = False,
        binary_item_id_ref: str | None = None,
        subst_face: str | None = None,
        subst_type: str | None = None,
        subst_is_embedded: bool = False,
        subst_binary_item_id_ref: str | None = None,
    ) -> str:
        """Ensure *face* is declared in ``hh:fontfaces`` and return its id.

        Hancom 관행(실코퍼스 176파일 전수): 글꼴 하나는 보통 7개 lang 블록
        전부에 선언된다 — *lang* 생략 시 그 관행대로 전부(``FONTFACE_LANGS``)
        에 등록해, 등록 뒤 ``ensure_run(font=face)`` 의 ``fontRef`` 7개 속성이
        전부 유효한 해당-블록 id 를 가리키게 한다(블록마다 id 채번이 독립이라
        다른 블록 id 를 빌려 쓰면 잘못된 글꼴을 가리킬 수 있다).

        *face* 가 이미 그 lang 블록에 있으면(``ensure_style`` 의 이름 dedupe와
        같은 관용구) 기존 id 를 재사용한다. 여러 블록에 걸쳐 등록할 때
        블록마다 id 가 갈릴 수 있으므로, 반환값은 *정규 순서상 첫* lang
        블록의 id 다. ``subst_face``/``subst_type`` 을 주면 ``hh:substFont``
        대체 글꼴도 함께 방출한다(dedupe 로 기존 ``hh:font`` 를 재사용하는
        경우는 대체 글꼴을 새로 끼워 넣지 않는다 — 기존 선언을 조용히
        바꾸지 않는다는 6.0 원칙).
        """

        from ..errors import HwpxStateError, HwpxValueError

        normalized_face = (face or "").strip()
        if not normalized_face:
            raise HwpxValueError("face must not be empty", code="style-font-face-empty")

        normalized_type = _validate_font_type(font_type, param_name="font_type")
        normalized_subst_face, normalized_subst_type = _resolve_font_substitute(
            subst_face, subst_type
        )
        langs = _normalize_font_langs(lang)

        fontfaces = self._fontfaces_element(create=True)
        if fontfaces is None:  # pragma: no cover - defensive branch
            raise HwpxStateError(
                "failed to create <fontfaces> element",
                code="style-font-container-create-failed",
            )

        primary_id: str | None = None
        for lang_name in langs:
            fontface = self._fontface_element(fontfaces, lang_name, create=True)
            if fontface is None:  # pragma: no cover - defensive branch
                raise HwpxStateError(
                    "failed to create <fontface> element",
                    code="style-font-container-create-failed",
                    context={"lang": lang_name},
                )
            font_id = _find_font_id(fontface, normalized_face)
            if font_id is None:
                font_id = _allocate_font_id(fontface)
                font_element = _build_font_element(
                    font_id=font_id,
                    face=normalized_face,
                    font_type=normalized_type,
                    is_embedded=is_embedded,
                    binary_item_id_ref=binary_item_id_ref,
                    subst_face=normalized_subst_face,
                    subst_type=normalized_subst_type,
                    subst_is_embedded=subst_is_embedded,
                    subst_binary_item_id_ref=subst_binary_item_id_ref,
                )
                if isinstance(fontface, LET._Element):
                    font_element = LET.fromstring(ET.tostring(font_element, encoding="utf-8"))
                fontface.append(font_element)
                fontface.set("fontCnt", str(len(fontface.findall(f"{_HH}font"))))
                self.mark_dirty()
            if primary_id is None:
                primary_id = font_id

        assert primary_id is not None  # langs is non-empty (validated by _normalize_font_langs)
        return primary_id

    def ensure_shading_border_fill(
        self,
        color: str | None = None,
        *,
        fill_image: Mapping[str, str] | None = None,
        fill_gradient: Mapping[str, object] | None = None,
        base_border_fill_id: str | int | None = None,
    ) -> str:
        element = self._border_fills_element(create=True)
        if element is None:  # pragma: no cover - defensive branch
            raise RuntimeError("failed to create <borderFills> element")
        has_alt_fill = fill_image is not None or fill_gradient is not None
        face_color = "none" if has_alt_fill else (_normalize_color(color) or "none")

        matched = _find_shading_border_fill_id(
            element, face_color=face_color, fill_image=fill_image, fill_gradient=fill_gradient,
        )
        if matched:
            return matched

        base_element: ET.Element | None = None
        if base_border_fill_id is not None:
            base_element = element.find(f"{_HH}borderFill[@id='{base_border_fill_id}']")
        if base_element is None:
            existing_basic = self.find_basic_border_fill_id()
            if existing_basic is not None:
                base_element = element.find(f"{_HH}borderFill[@id='{existing_basic}']")
        new_id = self._allocate_border_fill_id(element)
        if base_element is None:
            new_border_fill = _create_basic_border_fill_element(new_id)
        else:
            new_border_fill = deepcopy(base_element)
            new_border_fill.set("id", new_id)
            for child in list(new_border_fill):
                if _element_local_name(child) == "fillBrush":
                    new_border_fill.remove(child)

        _append_fill_brush(
            new_border_fill, fill_color=face_color, fill_image=fill_image, fill_gradient=fill_gradient,
        )
        _attach_new_child(element, new_border_fill)
        _update_item_count(element, "borderFill")
        self.mark_dirty()
        return new_id

    @property
    def border_fills(self) -> dict[str, GenericElement]:
        element = self._border_fills_element()
        if element is None:
            return {}

        fill_list = self._parsed(element, parse_border_fills)
        mapping: dict[str, GenericElement] = {}
        for border_fill in fill_list.fills:
            raw_id = border_fill.attributes.get("id")
            keys: list[str] = []
            if raw_id:
                keys.append(raw_id)
                try:
                    normalized = str(int(raw_id))
                except ValueError:
                    normalized = None
                if normalized and normalized not in keys:
                    keys.append(normalized)
            for key in keys:
                if key not in mapping:
                    mapping[key] = border_fill
        return mapping

    def border_fill(self, border_fill_id_ref: int | str | None) -> GenericElement | None:
        return self._lookup_by_id(self.border_fills, border_fill_id_ref)

    @staticmethod
    def _convert_to_lxml(element: ET.Element) -> LET._Element:
        # The header tree is lxml already; only a plain ElementTree element needs the round trip.
        if isinstance(element, LET._Element):
            return element
        return LET.fromstring(ET.tostring(element, encoding="utf-8"))

    def _parsed(self, element: ET.Element, parse: Callable[[LET._Element], T]) -> T:
        """``parse(element)``, kept until the header is marked dirty or the element's XML differs.

        The kept result is compared by the element's serialized bytes, so an edit made on the tree
        without ``mark_dirty()`` is seen as well.  Callers get the kept objects themselves, as
        ``char_property`` gives its cached styles: treat them as read-only.
        """

        if not isinstance(element, LET._Element):
            return parse(self._convert_to_lxml(element))
        stamp = LET.tostring(element)
        key = (parse, element)
        kept = self._lookup_cache.get(key)
        if kept is not None and kept[0] == stamp:
            return kept[1]  # type: ignore[return-value]
        value = parse(element)
        if len(self._lookup_cache) >= 4096:
            self._lookup_cache.clear()
        self._lookup_cache[key] = (stamp, value)
        return value

    @staticmethod
    def _lookup_by_id(mapping: dict[str, T], identifier: int | str | None) -> T | None:
        if identifier is None:
            return None

        if isinstance(identifier, str):
            key = identifier.strip()
        else:
            key = str(identifier)

        if not key:
            return None

        value = mapping.get(key)
        if value is not None:
            return value

        try:
            normalized = str(int(key))
        except (TypeError, ValueError):
            return None
        return mapping.get(normalized)

    @property
    def begin_numbering(self) -> DocumentNumbering:
        element = self._begin_num_element()
        if element is None:
            return DocumentNumbering()
        return DocumentNumbering(
            page=_get_int_attr(element, "page", 1),
            footnote=_get_int_attr(element, "footnote", 1),
            endnote=_get_int_attr(element, "endnote", 1),
            picture=_get_int_attr(element, "pic", 1),
            table=_get_int_attr(element, "tbl", 1),
            equation=_get_int_attr(element, "equation", 1),
        )

    def set_begin_numbering(
        self,
        *,
        page: int | None = None,
        footnote: int | None = None,
        endnote: int | None = None,
        picture: int | None = None,
        table: int | None = None,
        equation: int | None = None,
    ) -> None:
        element = self._begin_num_element(create=True)
        if element is None:
            return

        current = self.begin_numbering
        values = {
            "page": page if page is not None else current.page,
            "footnote": footnote if footnote is not None else current.footnote,
            "endnote": endnote if endnote is not None else current.endnote,
            "pic": picture if picture is not None else current.picture,
            "tbl": table if table is not None else current.table,
            "equation": equation if equation is not None else current.equation,
        }

        changed = False
        for attr, value in values.items():
            safe_value = str(max(value, 0))
            if element.get(attr) != safe_value:
                element.set(attr, safe_value)
                changed = True

        if changed:
            self.mark_dirty()

    @property
    def memo_shapes(self) -> dict[str, MemoShape]:
        memo_props_element = self._memo_properties_element()
        if memo_props_element is None:
            return {}

        memo_shapes = [
            memo_shape_from_attributes(child.attrib)
            for child in memo_props_element.findall(f"{_HH}memoPr")
        ]
        memo_properties = MemoProperties(
            item_cnt=parse_int(memo_props_element.get("itemCnt")),
            memo_shapes=memo_shapes,
            attributes={
                key: value
                for key, value in memo_props_element.attrib.items()
                if key != "itemCnt"
            },
        )
        return memo_properties.as_dict()

    def memo_shape(self, memo_shape_id_ref: int | str | None) -> MemoShape | None:
        if memo_shape_id_ref is None:
            return None

        if isinstance(memo_shape_id_ref, str):
            key = memo_shape_id_ref.strip()
        else:
            key = str(memo_shape_id_ref)

        if not key:
            return None

        shapes = self.memo_shapes
        shape = shapes.get(key)
        if shape is not None:
            return shape

        try:
            normalized = str(int(key))
        except (TypeError, ValueError):
            return None
        return shapes.get(normalized)

    def ensure_memo_shape(
        self,
        *,
        width: int = 15591,
        line_width: int | str = 1,
        line_type: str = "SOLID",
        line_color: str = "#000000",
        fill_color: str = "#CCFF99",
        active_color: str = "#FFFF99",
        memo_type: str = "NOMAL",
    ) -> str:
        element = self._memo_properties_element(create=True)
        if element is None:  # pragma: no cover - defensive branch
            raise RuntimeError("failed to create <memoProperties> element")
        spec = _normalize_memo_shape_spec(
            width=width, line_width=line_width, line_type=line_type, line_color=line_color,
            fill_color=fill_color, active_color=active_color, memo_type=memo_type,
        )
        shape_id, new_memo_pr = _ensure_memo_shape(element, spec)
        if new_memo_pr is None:
            return shape_id
        _attach_new_child(element, new_memo_pr)
        _update_item_count(element, "memoPr")
        self.mark_dirty()
        return shape_id

    @property
    def bullets(self) -> dict[str, Bullet]:
        bullets_element = self._bullets_element()
        if bullets_element is None:
            return {}

        bullet_list = self._parsed(bullets_element, parse_bullets)
        return bullet_list.as_dict()

    def bullet(self, bullet_id_ref: int | str | None) -> Bullet | None:
        return self._lookup_by_id(self.bullets, bullet_id_ref)

    @property
    def paragraph_properties(self) -> dict[str, ParagraphProperty]:
        para_props_element = self._para_properties_element()
        if para_props_element is None:
            return {}

        para_properties = self._parsed(para_props_element, parse_paragraph_properties)
        return para_properties.as_dict()

    def paragraph_property(
        self, para_pr_id_ref: int | str | None
    ) -> ParagraphProperty | None:
        # Parse only the hh:paraPr asked for, under the keys paragraph_properties gives it; parsing
        # them all on each lookup cost most of a second in a header of many paragraph shapes.
        parent = self._para_properties_element()
        children = [] if parent is None else list(parent)
        # The id -> element index is kept while the list has the same children with the same ids.
        stamp = (children, [(child.tag, child.get("id")) for child in children])
        kept = self._para_pr_index
        if kept is not None and kept[0] == stamp:
            elements = kept[1]
        else:
            elements = {}
            for child in children:
                raw = child.get("id") if _element_local_name(child) == "paraPr" else None
                for key in (raw, str(int(raw)) if raw and raw.strip().lstrip("+-").isdigit() else None):
                    if key and key not in elements:
                        elements[key] = child
            self._para_pr_index = (stamp, elements)
        found = self._lookup_by_id(elements, para_pr_id_ref)
        return None if found is None else self._parsed(found, parse_paragraph_property)

    @property
    def tab_properties(self) -> dict[str, TabDefinition]:
        element = self._tab_properties_element()
        if element is None:
            return {}
        return self._parsed(element, parse_tab_definitions).as_dict()

    def tab_property(self, tab_pr_id_ref: int | str | None) -> TabDefinition | None:
        return self._lookup_by_id(self.tab_properties, tab_pr_id_ref)

    @property
    def styles(self) -> dict[str, Style]:
        styles_element = self._styles_element()
        if styles_element is None:
            return {}

        style_list = self._parsed(styles_element, parse_styles)
        return style_list.as_dict()

    def style(self, style_id_ref: int | str | None) -> Style | None:
        return self._lookup_by_id(self.styles, style_id_ref)

    @property
    def track_changes(self) -> dict[str, TrackChange]:
        changes_element = self._track_changes_element()
        if changes_element is None:
            return {}

        change_list = self._parsed(changes_element, parse_track_changes)
        return change_list.as_dict()

    def track_change(self, change_id_ref: int | str | None) -> TrackChange | None:
        return self._lookup_by_id(self.track_changes, change_id_ref)

    @property
    def track_change_authors(self) -> dict[str, TrackChangeAuthor]:
        authors_element = self._track_change_authors_element()
        if authors_element is None:
            return {}

        author_list = self._parsed(authors_element, parse_track_change_authors)
        return author_list.as_dict()

    def track_change_author(
        self, author_id_ref: int | str | None
    ) -> TrackChangeAuthor | None:
        return self._lookup_by_id(self.track_change_authors, author_id_ref)

    @property
    def dirty(self) -> bool:
        return self._dirty

    def mark_dirty(self) -> None:
        self._dirty = True
        self._lookup_cache.clear()
        self._para_pr_index = None

    def reset_dirty(self) -> None:
        self._dirty = False

    # ------------------------------------------------------------------
    # BinData / Image management
    # ------------------------------------------------------------------

    def _bin_data_list_element(self, create: bool = False) -> ET.Element | None:
        """Return the ``<hh:binDataList>`` element inside ``<hh:refList>``."""

        ref_list = self._ref_list_element(create=create)
        if ref_list is None:
            return None
        element = ref_list.find(f"{_HH}binDataList")
        if element is None and create:
            element = ref_list.makeelement(f"{_HH}binDataList", {"itemCnt": "0"})
            ref_list.append(element)
            self.mark_dirty()
        return element

    def _update_bin_data_list_count(self, bin_data_list: ET.Element) -> None:
        count = len(list(bin_data_list.findall(f"{_HH}binItem")))
        bin_data_list.set("itemCnt", str(count))

    def _allocate_bin_item_id(self, bin_data_list: ET.Element) -> str:
        """Return the next available numeric id for a ``<hh:binItem>``."""

        existing: set[int] = set()
        for child in bin_data_list.findall(f"{_HH}binItem"):
            raw = child.get("id")
            if raw is not None:
                try:
                    existing.add(int(raw))
                except ValueError:
                    pass
        next_id = 0 if not existing else max(existing) + 1
        return str(next_id)

    def add_bin_item(
        self,
        *,
        item_type: str = "Embedding",
        bin_data_id: str | None = None,
        format: str | None = None,
        a_path: str | None = None,
        r_path: str | None = None,
    ) -> tuple[str, ET.Element]:
        """Add a ``<hh:binItem>`` and return ``(id, element)``.

        For embedded images *bin_data_id* should be the ``BIN0001.jpg``-style
        identifier stored in the ZIP and *format* should be the image format
        extension (``jpg``, ``png``, …).
        """

        bin_data_list = self._bin_data_list_element(create=True)
        if bin_data_list is None:  # pragma: no cover
            raise RuntimeError("failed to create <binDataList> element")

        item_id = self._allocate_bin_item_id(bin_data_list)

        attrs: dict[str, str] = {"id": item_id, "Type": item_type}
        if bin_data_id is not None:
            attrs["BinData"] = bin_data_id
        if format is not None:
            attrs["Format"] = format
        if a_path is not None:
            attrs["APath"] = a_path
        if r_path is not None:
            attrs["RPath"] = r_path

        element = bin_data_list.makeelement(f"{_HH}binItem", attrs)
        bin_data_list.append(element)
        self._update_bin_data_list_count(bin_data_list)
        self.mark_dirty()
        return item_id, element

    def list_bin_items(self) -> list[dict[str, str]]:
        """Return a list of dicts describing each ``<hh:binItem>``."""

        bin_data_list = self._bin_data_list_element()
        if bin_data_list is None:
            return []
        items: list[dict[str, str]] = []
        for child in bin_data_list.findall(f"{_HH}binItem"):
            items.append(dict(child.attrib))
        return items

    def remove_bin_item(self, item_id: str | int) -> bool:
        """Remove a ``<hh:binItem>`` by ID.  Returns ``True`` if removed."""

        bin_data_list = self._bin_data_list_element()
        if bin_data_list is None:
            return False
        target_id = str(item_id)
        for child in bin_data_list.findall(f"{_HH}binItem"):
            if child.get("id") == target_id:
                bin_data_list.remove(child)
                self._update_bin_data_list_count(bin_data_list)
                self.mark_dirty()
                return True
        return False

    def to_bytes(self) -> bytes:
        return _serialize_xml(self._element)

__all__ = ["HwpxOxmlHeader"]
